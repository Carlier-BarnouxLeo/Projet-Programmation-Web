//alert("bien relié");


function affichage_tab_general(nomtab){
    const tab = document.getElementById(nomtab);
    const situation = window.getComputedStyle(tab).display;

    if (situation === "none") {
        tab.style.display = "block";
    } else {
        tab.style.display = "none";
    }
}


/*
var tab0 = false;
var tab1 = false;
var tab4 = false;
var tab3 = false;
var tab5 = false;
var tab6 = false;
var tab7 = false;
var tab8 = false;
var tab9 = false;
var tab10 = false;

function affichage_tab_prepSc(){
    const tab = document.getElementById('tab_prepSc');

    if (!(tab0)){
        tab.style.display="block";
        tab0 = true;
    }
    else{
        tab.style.display="none";
        tab0 = false;
    }
}

function affichage_tab_prepP(){
    const tab = document.getElementById('tab_prepP');
    
    if (!(tab1)){
        tab.style.display="block";
        tab1 = true;
    }
    else{
        tab.style.display="none";
        tab1 = false;
    }
}

function affichage_tab_prepBN(){
    const tab = document.getElementById('tab_prepBN');
    
    if (!(tab4)){
        tab.style.display="block";
        tab4 = true;
    }
    else{
        tab.style.display="none";
        tab4 = false;
    }
}

function affichage_tab_cycleI(){
    const tab = document.getElementById('tab_InfoCycI');
    const tab2 = document.getElementById('tab_filiereCycI');

    if (!(tab3)){
        tab.style.display="block";
        tab2.style.display="block";
        tab3 = true;
    }
    else{
        tab.style.display="none";
        tab2.style.display="none";
        tab3 = false;
    }
}


function affichage_tab_bachTN() {
    const tab = document.getElementById('tab_bachTN');

    if (!tab5) {
        tab.style.display = "block";
        tab5 = true;
    } else {
        tab.style.display = "none";
        tab5 = false;
    }
}


function affichage_tab_mastTN() {
    const tab = document.getElementById('tab_mastTN');

    if (!tab6) {
        tab.style.display = "block";
        tab6 = true;
    } else {
        tab.style.display = "none";
        tab6 = false;
    }
}


function affichage_tab_bachDM() {
    const tab = document.getElementById('tab_bachDM');

    if (!tab7) {
        tab.style.display = "block";
        tab7 = true;
    } else {
        tab.style.display = "none";
        tab7 = false;
    }
}


function affichage_tab_mastDM() {
    const tab = document.getElementById('tab_mastDM');

    if (!tab8) {
        tab.style.display = "block";
        tab8 = true;
    } else {
        tab.style.display = "none";
        tab8 = false;
    }
}


function affichage_tab_btsSIO() {
    const tab = document.getElementById('tab_btsSIO');

    if (!tab9) {
        tab.style.display = "block";
        tab9 = true;
    } else {
        tab.style.display = "none";
        tab9 = false;
    }
}

function affichage_tab_btsCom() {
    const tab = document.getElementById('tab_btsCom');

    if (!tab10) {
        tab.style.display = "block";
        tab10 = true;
    } else {
        tab.style.display = "none";
        tab10 = false;
    }
}


*/
